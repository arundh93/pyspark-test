import pkgutil

config = pkgutil.get_data(__name__, 'config.yml')
